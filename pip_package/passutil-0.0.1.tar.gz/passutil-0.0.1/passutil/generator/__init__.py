"""Classic init fileDB for the module."""
