"""Init file for the root module : passutil."""
