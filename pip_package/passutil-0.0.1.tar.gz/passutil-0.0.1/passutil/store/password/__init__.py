"""Init package for password class."""
