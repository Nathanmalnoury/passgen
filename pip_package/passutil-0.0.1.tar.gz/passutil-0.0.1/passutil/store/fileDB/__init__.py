"""Init file for the fileDB file, in charge of keeping a record of the different Password Files in the OS."""
