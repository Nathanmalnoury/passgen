"""Init file for store module."""
